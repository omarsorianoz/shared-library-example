#	Archetype Usage


##	Pre requirements
Before we start, this is the environment that should be used:
You must have access to GCP and specifically to Repository (Requested by to the DevOps area).
You must have configured the Maven settings file.
##	Tools
- JDK 11
- Maven 3 or higher
- Python 3.9 or higher
- Git 2.33.0 or higher
#	 Configuraciones
##	MVN
-	In case you lack the maven settings.xml file.
-	Locate the Maven installation directory for your operating system.
-	It is usually installed in the USER_HOME/.m2/ directory.
-	For Linux or Mac this is ~/.m2/
-	For Windows it is \Documents and Settings\USER_NAME.m2\ or \Users\USER_NAME.m2
-	If you cannot find a settings.xml file, copy the settings.xml file from the USER_HOME/.m2/conf/ directory to the USER_HOME/ directory.
-	If the file exists, back up and generate one with the same name, but with the content detailed in this document
m2/
	-	If you do not have a file, you can copy the following content:

			<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0" xmlns:xsi="
			http://www.w3.org/2001/XMLSchema-instance"
			xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0
			https://maven.apache.org/xsd/settings-1.0.0.xsd">
			<localRepository>${user.home}/.m2/repository</localRepository>
			<interactiveMode>true</interactiveMode>
			<offline>false</offline>
			</settings>
	
##	Proyecto Base

The **ent-incentivos-microservice-archetypes-python** project is the template with the layers that are defined within the **Gentera** architecture.

The project must be downloaded at the following link:

https://source.cloud.google.com/ent-scr/ent-incentivos-microservice-archetypes-python

Enter the project and execute the following command:

		cd /<path>/ent-incentivos-microservice-archetypes-python
		mvn clean install

When executing the command, the console will have a similar result:

	[INFO] Scanning for projects...
	[INFO] 
	[INFO] -------------< com.gentera.archetype:ms-back-archetype-py >-------------
	[INFO] Building ms-back-archetype-py 0.0.2-SNAPSHOT
	[INFO] --------------------------[ maven-archetype ]---------------------------
	[INFO] 
	[INFO] --- maven-clean-plugin:3.1.0:clean (default-clean) @ ms-back-archetype-py ---
	[INFO] Deleting /opt/gentera/ent-incentivos-microservice-archetypes-python/target
	[INFO] 
	[INFO] --- maven-resources-plugin:3.2.0:resources (default-resources) @ ms-back-archetype-py ---
	[INFO] Using 'UTF-8' encoding to copy filtered resources.
	[INFO] Using 'UTF-8' encoding to copy filtered properties files.
	[INFO] Copying 0 resource
	[INFO] Copying 156 resources
	[INFO] 
	[INFO] --- maven-resources-plugin:3.2.0:testResources (default-testResources) @ ms-back-archetype-py ---
	[INFO] Using 'UTF-8' encoding to copy filtered resources.
	[INFO] Using 'UTF-8' encoding to copy filtered properties files.
	[INFO] skip non existing resourceDirectory /opt/gentera/ent-incentivos-microservice-archetypes-python/test-resources
	[INFO] 
	[INFO] --- maven-archetype-plugin:3.2.1:jar (default-jar) @ ms-back-archetype-py ---
	[INFO] Building archetype jar: /opt/gentera/ent-incentivos-microservice-archetypes-python/target/ms-back-archetype-py-0.0.2-SNAPSHOT.jar
	[INFO] Building jar: /opt/gentera/ent-incentivos-microservice-archetypes-python/target/ms-back-archetype-py-0.0.2-SNAPSHOT.jar
	[INFO] 
	[INFO] --- maven-archetype-plugin:3.2.1:integration-test (default-integration-test) @ ms-back-archetype-py ---
	[WARNING] No Archetype IT projects: root 'projects' directory not found.
	[INFO] 
	[INFO] --- maven-install-plugin:2.5.2:install (default-install) @ ms-back-archetype-py ---
	[INFO] Installing /opt/gentera/ent-incentivos-microservice-archetypes-python/target/ms-back-archetype-py-0.0.2-SNAPSHOT.jar to /home/cicd/.m2/repository/com/gentera/archetype/ms-back-archetype-py/0.0.2-SNAPSHOT/ms-back-archetype-py-0.0.2-SNAPSHOT.jar
	[INFO] Installing /opt/gentera/ent-incentivos-microservice-archetypes-python/pom.xml to /home/cicd/.m2/repository/com/gentera/archetype/ms-back-archetype-py/0.0.2-SNAPSHOT/ms-back-archetype-py-0.0.2-SNAPSHOT.pom
	[INFO] 
	[INFO] --- maven-archetype-plugin:3.2.1:update-local-catalog (default-update-local-catalog) @ ms-back-archetype-py ---
	[INFO] ------------------------------------------------------------------------
	[INFO] BUILD SUCCESS
	[INFO] ------------------------------------------------------------------------

once you have the result: **BUILD SUCESS**
the following command should be executed:

	mvn install:install-file -Dfile=target/ms-back-archetype-py-0.0.2-SNAPSHOT.jar -DgroupId=com.gentera.archetype-py -DartifactId=ms-back-archetype-py -Dversion=0.0.2-SNAPSHOT -Dpackaging=jar

Presenting a final result in the console as shown below:

	[INFO] Scanning for projects...
	[INFO] 
	[INFO] -------------< com.gentera.archetype:ms-back-archetype-py >-------------
	[INFO] Building ms-back-archetype-py 0.0.2-SNAPSHOT
	[INFO] --------------------------[ maven-archetype ]---------------------------
	[INFO] 
	[INFO] --- maven-install-plugin:2.5.2:install-file (default-cli) @ ms-back-archetype-py ---
	[INFO] Installing /opt/gentera/ent-incentivos-microservice-archetypes-python/target/ms-back-archetype-py-0.0.2-SNAPSHOT.jar to /home/cicd/.m2/repository/com/gentera/archetype-py/ms-back-archetype-py/0.0.2-SNAPSHOT/ms-back-archetype-py-0.0.2-SNAPSHOT.jar
	[INFO] ------------------------------------------------------------------------
	[INFO] BUILD SUCCESS
	[INFO] ------------------------------------------------------------------------

After this execution, it is possible to reuse the Archetype.
in the route that you want to generate, ***it must not be within the same archetype folder.*** (It can be found in any other location on the PC where the microservice is required to be generated, except within the same project folder of the Archetype)
the following command should be executed:

	mvn archetype:generate -B -DarchetypeGroupId=com.gentera.archetype-py -DarchetypeArtifactId=ms-back-archetype-py -DarchetypeVersion=0.0.2-SNAPSHOT -DartifactId=gentera-back-ms-article -DserviceName=Article -DserviceNameFolder=article -Dtype=DELETE

Where the important aspects to consider are:
-DartifactId=**com.gentera.archetype-py**
Name of the microservice according to the standard in **Gentera**.
-DserviceName=**Articles**
Name of the service.
-DserviceNameFolder=**articles**
Name of the service, to name attributes of classes.
When executing the command, the following sequence will be presented in the console, for our example a microservice named: t will be generated
**gentera-back-ms-article**

		[INFO] Scanning for projects...
		[INFO] 
		[INFO] ------------------< org.apache.maven:standalone-pom >-------------------
		[INFO] Building Maven Stub Project (No POM) 1
		[INFO] --------------------------------[ pom ]---------------------------------
		[INFO] 
		[INFO] >>> maven-archetype-plugin:3.2.1:generate (default-cli) > generate-sources @ standalone-pom >>>
		[INFO] 
		[INFO] <<< maven-archetype-plugin:3.2.1:generate (default-cli) < generate-sources @ standalone-pom <<<
		[INFO] 
		[INFO] 
		[INFO] --- maven-archetype-plugin:3.2.1:generate (default-cli) @ standalone-pom ---
		[INFO] Generating project in Batch mode
		[INFO] Archetype repository not defined. Using the one from [com.gentera.archetype-py:ms-back-archetype-py:0.0.1-SNAPSHOT] found in catalog local
		[INFO] ----------------------------------------------------------------------------
		[INFO] Using following parameters for creating project from Archetype: ms-back-archetype-py:0.0.2-SNAPSHOT
		[INFO] ----------------------------------------------------------------------------
		[INFO] Parameter: groupId, Value: com.gentera.archetype-py
		[INFO] Parameter: artifactId, Value: gentera-back-ms-article
		[INFO] Parameter: version, Value: 0.0.2-SNAPSHOT
		[INFO] Parameter: package, Value: com.gentera.rest
		[INFO] Parameter: packageInPathFormat, Value: com/gentera/rest
		[INFO] Parameter: serviceNameFolder, Value: article
		[INFO] Parameter: package, Value: com.gentera.rest
		[INFO] Parameter: groupId, Value: com.gentera.archetype-py
		[INFO] Parameter: artifactId, Value: gentera-back-ms-article
		[INFO] Parameter: type, Value: DELETE
		[INFO] Parameter: serviceName, Value: Article
		[INFO] Parameter: version, Value: 0.0.2-SNAPSHOT
		[WARNING] Property 'init' was not specified, so the token in 'src///app/services/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/services/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/services/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/services/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/services/__pycache__/authentication.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/services/__pycache__/security.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/services/__pycache__/jwt.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/dependencies/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/dependencies/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/dependencies/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/dependencies/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/dependencies/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/dependencies/__pycache__/authentication.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/dependencies/__pycache__/database.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/errors/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/errors/__pycache__/http_error.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/errors/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/errors/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/errors/__pycache__/validation_error.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/routes/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/routes/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/__pycache__/api.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/__pycache__/tags.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/__pycache__/authentication.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/routes/articles/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/articles/__pycache__/articles_resource.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/articles/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/routes/articles/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/articles/__pycache__/articles_common.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/routes/articles/__pycache__/api.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/api/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/api/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/db/repositories/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/repositories/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/db/repositories/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/repositories/__pycache__/base.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/repositories/__pycache__/tags.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/repositories/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/repositories/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/repositories/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/db/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/migrations/__pycache__/env.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/db/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/__pycache__/events.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/__pycache__/errors.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/db/queries/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/queries/__pycache__/queries.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/queries/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/db/queries/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/db/queries/__pycache__/tables.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/models/schemas/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/schemas/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/models/schemas/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/schemas/__pycache__/rwschema.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/schemas/__pycache__/tags.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/schemas/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/schemas/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/schemas/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/schemas/__pycache__/jwt.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/models/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/models/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/__pycache__/common.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/models/domain/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/domain/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/models/domain/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/domain/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/domain/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/domain/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/models/domain/__pycache__/rwmodel.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/__init__.py' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/resources/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/resources/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/resources/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/resources/__pycache__/strings.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/core/__init__.py' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/core/settings/__init__.py' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/settings/__pycache__/test.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/settings/__pycache__/development.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/settings/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/core/settings/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/settings/__pycache__/base.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/settings/__pycache__/app.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/settings/__pycache__/production.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/__pycache__/logging.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/core/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/__pycache__/events.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/core/__pycache__/config.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/__pycache__/main.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'pycache' was not specified, so the token in 'src///app/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in 'src///app/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.github
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/pom.xml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/README.rst
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.env
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.gitignore
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/alembic.ini
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.env.example
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/Dockerfile.txt
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.dockerignore
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/README.md
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.github/workflows/deploy.yml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.github/workflows/styles.yml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.github/workflows/conduit.yml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.github/workflows/tests.yml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.github/assets/logo.png
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/.github/dependabot.yml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/docker-compose.yml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/pyproject.toml
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/jwt.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/security.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/services/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/articles.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/services/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/services/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/services/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/__pycache__/articles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/services/__pycache__/authentication.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/__pycache__/authentication.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/services/__pycache__/security.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/__pycache__/security.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/services/__pycache__/jwt.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/__pycache__/jwt.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/services/authentication.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/main.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/dependencies/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/articles.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/profiles.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/database.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/dependencies/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/dependencies/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/dependencies/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/__pycache__/profiles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/dependencies/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/__pycache__/articles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/dependencies/__pycache__/authentication.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/__pycache__/authentication.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/dependencies/__pycache__/database.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/__pycache__/database.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/dependencies/authentication.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/errors/validation_error.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/errors/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/errors/__init__.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/errors/__pycache__/http_error.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/errors/__pycache__/http_error.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/errors/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/errors/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/errors/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/errors/__pycache__/validation_error.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/errors/__pycache__/validation_error.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/errors/http_error.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/users.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/routes/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/profiles.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/routes/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/__pycache__/api.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/__pycache__/api.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/__pycache__/tags.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/__pycache__/tags.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/__pycache__/users.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/__pycache__/profiles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/__pycache__/authentication.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/__pycache__/authentication.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/articles_resource.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/routes/articles/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/__init__.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/articles/__pycache__/articles_resource.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/__pycache__/articles_resource.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/articles/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/routes/articles/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/articles/__pycache__/articles_common.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/__pycache__/articles_common.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/routes/articles/__pycache__/api.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/__pycache__/api.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/api.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/articles/articles_common.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/authentication.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/api.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/routes/tags.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/__init__.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/api/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/api/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/api/__pycache__/__init__.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/errors.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/users.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/base.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/db/repositories/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/articles.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/profiles.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/repositories/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/db/repositories/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/repositories/__pycache__/base.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/__pycache__/base.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/repositories/__pycache__/tags.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/__pycache__/tags.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/repositories/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/__pycache__/users.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/repositories/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/__pycache__/profiles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/repositories/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/__pycache__/articles.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/repositories/tags.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/db/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/migrations/versions/fdf8821871d7_main_tables.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/migrations/env.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/migrations/__pycache__/env.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/migrations/__pycache__/env.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/db/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/__pycache__/events.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/__pycache__/events.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/__pycache__/errors.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/__pycache__/errors.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/events.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/queries.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/tables.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/db/queries/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/__init__.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/queries/__pycache__/queries.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/__pycache__/queries.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/queries/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/db/queries/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/db/queries/__pycache__/tables.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/__pycache__/tables.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/sql/tags.sql
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/sql/users.sql
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/sql/profiles.sql
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/sql/articles.sql
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/db/queries/queries.pyi
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/common.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/jwt.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/users.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/models/schemas/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/articles.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/profiles.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/schemas/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/models/schemas/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/schemas/__pycache__/rwschema.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__pycache__/rwschema.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/schemas/__pycache__/tags.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__pycache__/tags.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/schemas/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__pycache__/users.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/schemas/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__pycache__/profiles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/schemas/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__pycache__/articles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/schemas/__pycache__/jwt.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/__pycache__/jwt.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/rwschema.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/schemas/tags.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/models/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/__init__.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/models/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/__pycache__/common.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/__pycache__/common.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/users.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/comments.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/models/domain/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/articles.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/profiles.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/domain/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/models/domain/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/domain/__pycache__/users.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/__pycache__/users.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/domain/__pycache__/profiles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/__pycache__/profiles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/domain/__pycache__/articles.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/__pycache__/articles.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/models/domain/__pycache__/rwmodel.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/__pycache__/rwmodel.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/models/domain/rwmodel.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/__init__.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/resources/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/resources/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/resources/strings.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/resources/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/resources/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/resources/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/resources/__pycache__/strings.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/resources/__pycache__/strings.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/logging.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/core/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/__init__.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/config.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/development.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/base.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/test.py
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/app.py
		[WARNING] Property 'init' was not specified, so the token in '//src/app/core/settings/__init__.py' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/__init__.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/settings/__pycache__/test.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/__pycache__/test.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/settings/__pycache__/development.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/__pycache__/development.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/settings/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/core/settings/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/settings/__pycache__/base.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/__pycache__/base.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/settings/__pycache__/app.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/__pycache__/app.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/settings/__pycache__/production.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/__pycache__/production.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/settings/production.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/__pycache__/logging.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/__pycache__/logging.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/core/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/__pycache__/__init__.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/__pycache__/events.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/__pycache__/events.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/core/__pycache__/config.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/__pycache__/config.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/core/events.py
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/__pycache__/main.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/__pycache__/main.cpython-310.pyc
		[WARNING] Property 'pycache' was not specified, so the token in '//src/app/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] Property 'init' was not specified, so the token in '//src/app/__pycache__/__init__.cpython-310.pyc' is not being replaced.
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/app/__pycache__/__init__.cpython-310.pyc
		[WARNING] CP Don't override file /opt/gentera/gentera-back-ms-article/src/poetry.lock
		[INFO] Project created from Archetype in dir: /opt/gentera/gentera-back-ms-article
		[INFO] ------------------------------------------------------------------------
		[INFO] BUILD SUCCESS
		[INFO] ------------------------------------------------------------------------
		[INFO] Total time:  8.487 s
		[INFO] Finished at: 2022-08-11T07:54:55-05:00
		[INFO] ------------------------------------------------------------------------

when obtaining the BUILD SUCCESS, a folder is generated with the layers defined for the BHD microservices, conceptually it is the
following, for this example the folder is named: <path>/**gentera-back-ms-article**/src

Rename the **Dockerfile.txt file** to **Dockerfile**, this task is very important, because it depends on the execution of the following commands

Enter the folder, and execute the following command:
	
		docker-compose up -d app

When you run the mentioned command the output is as follows

		Building app
		Sending build context to Docker daemon  423.4kB
		Step 1/9 : FROM python:3.9.10-slim
		 ---> 4acfa68b68bf
		Step 2/9 : ENV PYTHONUNBUFFERED 1
		 ---> Running in 80aa7bd10294
		Removing intermediate container 80aa7bd10294
		 ---> 7cd69e685feb
		Step 3/9 : EXPOSE 8000
		 ---> Running in 3ecc55a02752
		Removing intermediate container 3ecc55a02752
		 ---> e577fe5d9bcd
		Step 4/9 : WORKDIR /app
		 ---> Running in 0679f7a67193
		Removing intermediate container 0679f7a67193
		 ---> f68a42962778
		Step 5/9 : RUN apt-get update &&     apt-get install -y --no-install-recommends netcat &&     rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*
		 ---> Running in bbb231c6f2fc
		Get:1 http://security.debian.org/debian-security bullseye-security InRelease [48.4 kB]
		Get:2 http://deb.debian.org/debian bullseye InRelease [116 kB]
		Get:3 http://deb.debian.org/debian bullseye-updates InRelease [44.1 kB]
		Get:4 http://security.debian.org/debian-security bullseye-security/main amd64 Packages [175 kB]
		Get:5 http://deb.debian.org/debian bullseye/main amd64 Packages [8182 kB]
		Get:6 http://deb.debian.org/debian bullseye-updates/main amd64 Packages [2592 B]
		Fetched 8567 kB in 3s (2683 kB/s)
		Reading package lists...
		Reading package lists...
		Building dependency tree...
		Reading state information...
		The following additional packages will be installed:
		  libbsd0 libmd0 netcat-openbsd
		The following NEW packages will be installed:
		  libbsd0 libmd0 netcat netcat-openbsd
		0 upgraded, 4 newly installed, 0 to remove and 19 not upgraded.
		Need to get 187 kB of archives.
		After this operation, 404 kB of additional disk space will be used.
		Get:1 http://deb.debian.org/debian bullseye/main amd64 libmd0 amd64 1.0.3-3 [28.0 kB]
		Get:2 http://deb.debian.org/debian bullseye/main amd64 libbsd0 amd64 0.11.3-1 [108 kB]
		Get:3 http://deb.debian.org/debian bullseye/main amd64 netcat-openbsd amd64 1.217-3 [41.1 kB]
		Get:4 http://deb.debian.org/debian bullseye/main amd64 netcat all 1.10-46 [9728 B]
		debconf: delaying package configuration, since apt-utils is not installed
		Fetched 187 kB in 1s (228 kB/s)
		Selecting previously unselected package libmd0:amd64.
		(Reading database ... 7023 files and directories currently installed.)
		Preparing to unpack .../libmd0_1.0.3-3_amd64.deb ...
		Unpacking libmd0:amd64 (1.0.3-3) ...
		Selecting previously unselected package libbsd0:amd64.
		Preparing to unpack .../libbsd0_0.11.3-1_amd64.deb ...
		Unpacking libbsd0:amd64 (0.11.3-1) ...
		Selecting previously unselected package netcat-openbsd.
		Preparing to unpack .../netcat-openbsd_1.217-3_amd64.deb ...
		Unpacking netcat-openbsd (1.217-3) ...
		Selecting previously unselected package netcat.
		Preparing to unpack .../netcat_1.10-46_all.deb ...
		Unpacking netcat (1.10-46) ...
		Setting up libmd0:amd64 (1.0.3-3) ...
		Setting up libbsd0:amd64 (0.11.3-1) ...
		Setting up netcat-openbsd (1.217-3) ...
		update-alternatives: using /bin/nc.openbsd to provide /bin/nc (nc) in auto mode
		update-alternatives: warning: skip creation of /usr/share/man/man1/nc.1.gz because associated file /usr/share/man/man1/nc_openbsd.1.gz (of link group nc) doesn't exist
		update-alternatives: warning: skip creation of /usr/share/man/man1/netcat.1.gz because associated file /usr/share/man/man1/nc_openbsd.1.gz (of link group nc) doesn't exist
		Setting up netcat (1.10-46) ...
		Processing triggers for libc-bin (2.31-13+deb11u2) ...
		Removing intermediate container bbb231c6f2fc
		 ---> cea9073fca5a
		Step 6/9 : COPY poetry.lock pyproject.toml ./
		 ---> 67f666fdeff0
		Step 7/9 : RUN pip install poetry==1.1 &&     poetry config virtualenvs.in-project true &&     poetry install --no-dev
		 ---> Running in 5d7debec8d75
		Collecting poetry==1.1
		  Downloading poetry-1.1.0-py2.py3-none-any.whl (168 kB)
		Collecting poetry-core<2.0.0,>=1.0.0
		  Downloading poetry_core-1.0.8-py2.py3-none-any.whl (425 kB)
		Collecting keyring<22.0.0,>=21.2.0
		  Downloading keyring-21.8.0-py3-none-any.whl (32 kB)
		Collecting cachecontrol[filecache]<0.13.0,>=0.12.4
		  Downloading CacheControl-0.12.11-py2.py3-none-any.whl (21 kB)
		Collecting clikit<0.7.0,>=0.6.2
		  Downloading clikit-0.6.2-py2.py3-none-any.whl (91 kB)
		Collecting html5lib<2.0,>=1.0
		  Downloading html5lib-1.1-py2.py3-none-any.whl (112 kB)
		Collecting packaging<21.0,>=20.4
		  Downloading packaging-20.9-py2.py3-none-any.whl (40 kB)
		Collecting cleo<0.9.0,>=0.8.1
		  Downloading cleo-0.8.1-py2.py3-none-any.whl (21 kB)
		Collecting pexpect<5.0.0,>=4.7.0
		  Downloading pexpect-4.8.0-py2.py3-none-any.whl (59 kB)
		Collecting tomlkit<1.0.0,>=0.7.0
		  Downloading tomlkit-0.11.3-py3-none-any.whl (35 kB)
		Collecting requests-toolbelt<0.10.0,>=0.9.1
		  Downloading requests_toolbelt-0.9.1-py2.py3-none-any.whl (54 kB)
		Collecting shellingham<2.0,>=1.1
		  Downloading shellingham-1.5.0-py2.py3-none-any.whl (9.3 kB)
		Collecting crashtest<0.4.0,>=0.3.0
		  Downloading crashtest-0.3.1-py3-none-any.whl (7.0 kB)
		Collecting virtualenv<21.0.0,>=20.0.26
		  Downloading virtualenv-20.16.3-py2.py3-none-any.whl (8.8 MB)
		Collecting pkginfo<2.0,>=1.4
		  Downloading pkginfo-1.8.3-py2.py3-none-any.whl (26 kB)
		Collecting requests<3.0,>=2.18
		  Downloading requests-2.28.1-py3-none-any.whl (62 kB)
		Collecting cachy<0.4.0,>=0.3.0
		  Downloading cachy-0.3.0-py2.py3-none-any.whl (20 kB)
		Collecting msgpack>=0.5.2
		  Downloading msgpack-1.0.4-cp39-cp39-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (322 kB)
		Collecting lockfile>=0.9
		  Downloading lockfile-0.12.2-py2.py3-none-any.whl (13 kB)
		Collecting pylev<2.0,>=1.3
		  Downloading pylev-1.4.0-py2.py3-none-any.whl (6.1 kB)
		Collecting pastel<0.3.0,>=0.2.0
		  Downloading pastel-0.2.1-py2.py3-none-any.whl (6.0 kB)
		Collecting six>=1.9
		  Downloading six-1.16.0-py2.py3-none-any.whl (11 kB)
		Collecting webencodings
		  Downloading webencodings-0.5.1-py2.py3-none-any.whl (11 kB)
		Collecting jeepney>=0.4.2
		  Downloading jeepney-0.8.0-py3-none-any.whl (48 kB)
		Collecting SecretStorage>=3.2
		  Downloading SecretStorage-3.3.2-py3-none-any.whl (15 kB)
		Collecting pyparsing>=2.0.2
		  Downloading pyparsing-3.0.9-py3-none-any.whl (98 kB)
		Collecting ptyprocess>=0.5
		  Downloading ptyprocess-0.7.0-py2.py3-none-any.whl (13 kB)
		Collecting certifi>=2017.4.17
		  Downloading certifi-2022.6.15-py3-none-any.whl (160 kB)
		Collecting urllib3<1.27,>=1.21.1
		  Downloading urllib3-1.26.11-py2.py3-none-any.whl (139 kB)
		Collecting idna<4,>=2.5
		  Downloading idna-3.3-py3-none-any.whl (61 kB)
		Collecting charset-normalizer<3,>=2
		  Downloading charset_normalizer-2.1.0-py3-none-any.whl (39 kB)
		Collecting cryptography>=2.0
		  Downloading cryptography-37.0.4-cp36-abi3-manylinux_2_24_x86_64.whl (4.1 MB)
		Collecting cffi>=1.12
		  Downloading cffi-1.15.1-cp39-cp39-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (441 kB)
		Collecting pycparser
		  Downloading pycparser-2.21-py2.py3-none-any.whl (118 kB)
		Collecting distlib<1,>=0.3.5
		  Downloading distlib-0.3.5-py2.py3-none-any.whl (466 kB)
		Collecting platformdirs<3,>=2.4
		  Downloading platformdirs-2.5.2-py3-none-any.whl (14 kB)
		Collecting filelock<4,>=3.4.1
		  Downloading filelock-3.8.0-py3-none-any.whl (10 kB)
		Installing collected packages: pycparser, urllib3, idna, charset-normalizer, cffi, certifi, requests, pylev, pastel, msgpack, jeepney, cryptography, crashtest, webencodings, six, SecretStorage, pyparsing, ptyprocess, platformdirs, lockfile, filelock, distlib, clikit, cachecontrol, virtualenv, tomlkit, shellingham, requests-toolbelt, poetry-core, pkginfo, pexpect, packaging, keyring, html5lib, cleo, cachy, poetry
		Successfully installed SecretStorage-3.3.2 cachecontrol-0.12.11 cachy-0.3.0 certifi-2022.6.15 cffi-1.15.1 charset-normalizer-2.1.0 cleo-0.8.1 clikit-0.6.2 crashtest-0.3.1 cryptography-37.0.4 distlib-0.3.5 filelock-3.8.0 html5lib-1.1 idna-3.3 jeepney-0.8.0 keyring-21.8.0 lockfile-0.12.2 msgpack-1.0.4 packaging-20.9 pastel-0.2.1 pexpect-4.8.0 pkginfo-1.8.3 platformdirs-2.5.2 poetry-1.1.0 poetry-core-1.0.8 ptyprocess-0.7.0 pycparser-2.21 pylev-1.4.0 pyparsing-3.0.9 requests-2.28.1 requests-toolbelt-0.9.1 shellingham-1.5.0 six-1.16.0 tomlkit-0.11.3 urllib3-1.26.11 virtualenv-20.16.3 webencodings-0.5.1
		WARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv
		WARNING: You are using pip version 21.2.4; however, version 22.2.2 is available.
		You should consider upgrading via the '/usr/local/bin/python -m pip install --upgrade pip' command.
		Creating virtualenv ms-back-demo in /app/.venv
		Installing dependencies from lock file

		Package operations: 35 installs, 0 updates, 0 removals

		  • Installing idna (3.3)
		  • Installing pycparser (2.21)
		  • Installing sniffio (1.2.0)
		  • Installing anyio (3.5.0)
		  • Installing cffi (1.15.0)
		  • Installing dnspython (2.2.0)
		  • Installing greenlet (1.1.2)
		  • Installing markupsafe (2.0.1)
		  • Installing six (1.16.0)
		  • Installing typing-extensions (3.10.0.2)
		  • Installing asgiref (3.5.0)
		  • Installing bcrypt (3.2.0)
		  • Installing click (8.0.3)
		  • Installing contextlib2 (21.6.0)
		  • Installing email-validator (1.1.3)
		  • Installing h11 (0.12.0)
		  • Installing mako (1.1.6)
		  • Installing pydantic (1.9.0)
		  • Installing python-dotenv (0.19.2)
		  • Installing sqlalchemy (1.4.31)
		  • Installing starlette (0.17.1)
		  • Installing text-unidecode (1.3)
		  • Installing aiosql (3.3.1)
		  • Installing alembic (1.7.6)
		  • Installing asyncpg (0.25.0)
		  • Installing databases (0.5.5)
		  • Installing fastapi (0.73.0)
		  • Installing loguru (0.6.0)
		  • Installing passlib (1.7.4)
		  • Installing psycopg2-binary (2.9.3)
		  • Installing pyjwt (2.3.0)
		  • Installing pypika (0.48.8)
		  • Installing python-slugify (5.0.2)
		  • Installing unidecode (1.3.2)
		  • Installing uvicorn (0.17.4)
		Removing intermediate container 5d7debec8d75
		 ---> 0050d924b854
		Step 8/9 : COPY . ./
		 ---> e8a65ed5f91c
		Step 9/9 : CMD poetry run alembic upgrade head &&     poetry run uvicorn --host=0.0.0.0 app.main:app
		 ---> Running in f4c3376d7bf7
		Removing intermediate container f4c3376d7bf7
		 ---> 26fb72bd38b6
		Successfully built 26fb72bd38b6
		Successfully tagged src_app:latest
		WARNING: Image for service app was built because it did not already exist. To rebuild this image you must use `docker-compose build` or `docker-compose up --build`.
		Creating src_db_1 ... done
		Creating src_app_1 ... done

The execution generates 2 dockers 1 for the Database and the other for the application, during the course of the execution you can see the dependencies that must be set locally in case of an execution outside of dockers,

To validate being able to open the browser and consult:

	http://localhost:8000/redoc

or

	http://localhost:8000/docs
